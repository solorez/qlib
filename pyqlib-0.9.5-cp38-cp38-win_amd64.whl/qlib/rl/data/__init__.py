# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Common utilities to handle ad-hoc-styled data.

Most of these snippets comes from research project (paper code).
Please take caution when using them in production.
"""
